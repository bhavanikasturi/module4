package com.cg.learning.dao;

import java.util.List;

import com.cg.learning.beans.Product;

public interface IProductDAO {
	
	public Product getProduct(int id);
	public Product addProduct(Product Product);
	public Product deleteProduct(int id);
	public List<Product> getAllProducts();
	List<Product> getAllproducts();
}
