package com.cg.learning.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.learning.beans.Product;
import com.cg.learning.staticdb.ProductDB;

/**
 * 
 * @author bhanu DAO class with operations like create, delete , fetch on the
 *         HashMap
 */
public class ProductDAOImpl implements IProductDAO {
	static HashMap<Integer, Product> ProductIdMap = ProductDB.getProductIdMap();

	

	/**
	 * Fetching single Product details
	 * 
	 * @param id
	 * @return Product
	 */
	public Product getProduct(int id) {
		Product Product = ProductIdMap.get(id);
		return Product;
	}

	/**
	 * Creating a new Product
	 * 
	 * @param Product
	 * @return Product
	 */
	public Product addProduct(Product Product) {
		ProductIdMap.put(Product.getProductId(), Product);
		return Product;
	}

	/**
	 * Updating an existing Product
	 * 
	 * @param Product
	 * @return Product
	 */
	public Product updateProduct(Product Product) {
		if (Product.getProductId() <= 0)
			return null;
		ProductIdMap.put(Product.getProductId(), Product);
		return Product;

	}

	/**
	 * Deleting an existing Product
	 * 
	 * @param id
	 * @return Product
	 */
	public Product deleteProduct(int id) {
		return ProductIdMap.remove(id);
	}

	
	/**
	 * Fetching all details of products
	 * 
	 * @return List<Product>
	 */

	@Override
	public List<Product> getAllproducts() {
		List<Product> products = new ArrayList<Product>(ProductIdMap.values());
		return products;
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

}
