package com.cg.learning.beans;


public class Product {
	private int ProductId;
	private String ProductName;
	private long Price;

	public Product() {

	}

	public Product(int ProductId, String ProductName, long Price) {
		super();
		this.ProductId = ProductId;
		this.ProductName = ProductName;
		this.Price = Price;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int ProductId) {
		this.ProductId = ProductId;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String ProductName) {
		this.ProductName = ProductName;
	}

	public long getPrice() {
		return Price;
	}

	public void setPrice(long Price) {
		this.Price = Price;
	}

}
