package com.cg.learning.service;

import java.util.List;

import com.cg.learning.beans.Product;
import com.cg.learning.dao.IProductDAO;
import com.cg.learning.dao.ProductDAOImpl;

/**
 * ProductService acting as a service layer dispatching calls to DAO layer
 * 
 * @author bhanu
 *
 */
public class ProductService implements IProductService {
	IProductDAO dao;

	public ProductService() {
		dao = new ProductDAOImpl();
	}

	/**
	 * Fetching all details of Products
	 * 
	 * @return List<Product>
	 */
	public List<Product> getAllProducts() {
		return dao.getAllProducts();
	}

	/**
	 * Fetching single Product details
	 * 
	 * @param id
	 * @return Product
	 */
	public Product getProduct(int id) {
		return dao.getProduct(id);
	}

	/**
	 * Creating a new Product
	 * 
	 * @param Product
	 * @return Product
	 */
	public Product addProduct(Product Product) {
		return dao.addProduct(Product);
	}

	/**
	 * Deleting an existing Product
	 * 
	 * @param id
	 * @return Product
	 */
	public Product deleteProduct(int id) {
		return dao.deleteProduct(id);
	}

}
