package com.cg.learning.service;

import java.util.List;

import com.cg.learning.beans.Product;

public interface IProductService {
	public List<Product> getAllProducts();
	public Product getProduct(int id);
	public Product addProduct(Product Product);
	public Product deleteProduct(int id);
}
