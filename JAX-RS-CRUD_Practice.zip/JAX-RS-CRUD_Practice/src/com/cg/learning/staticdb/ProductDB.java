package com.cg.learning.staticdb;

import java.util.HashMap;

import com.cg.learning.beans.Product;

/**
 * 
 * @author bhanu
 * Static DB class, hosting Product details in a HashMap
 */
public class ProductDB {
	static HashMap<Integer, Product> ProductIdMap = getProductIdMap();
	
	static {
		if (ProductIdMap == null) {
			ProductIdMap = new HashMap<Integer, Product>();
			Product IpadProduct = new Product(1, "Ipad", 199999);
			Product CoolpadProduct = new Product(4, "Coolpad", 299999);
			Product TvProduct = new Product(3, "Tv", 289999);
			Product PhoneProduct = new Product(2, "Phone", 1799999);

			ProductIdMap.put(1, IpadProduct);
			ProductIdMap.put(4, CoolpadProduct);
			ProductIdMap.put(3, TvProduct);
			ProductIdMap.put(2, PhoneProduct);
		}

	}
	/**
	 * This is a getter method of HashMap
	 * @return HashMap<Integer, Product>
	 */
	public static HashMap<Integer, Product> getProductIdMap() {
		return ProductIdMap;
	}
}
