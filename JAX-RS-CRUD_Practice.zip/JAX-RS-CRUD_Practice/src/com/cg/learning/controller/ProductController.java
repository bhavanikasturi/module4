package com.cg.learning.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.cg.learning.beans.Product;
import com.cg.learning.service.IProductService;
import com.cg.learning.service.ProductService;


@Path("/products")
public class ProductController {
	IProductService ProductService;

	public ProductController() {
		ProductService = new ProductService();
	}

	/**
	 * Method to list all Product details, supporting HTTP GET method and
	 * produces Media type of JSON
	 * 
	 * @return List<Product>
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getproducts() {
		List<Product> listOfproducts = ProductService.getAllProducts();
		return listOfproducts;
	}

	/**
	 * Method to print specific Product details, supporting HTTP GET method and
	 * produces Media type of JSON
	 * 
	 * @PathParam is used to extract parameter from URL
	 * @return Product
	 */
	@GET
	@Path("/search")
	@Produces(MediaType.APPLICATION_JSON)
	public Product getProductById(@PathParam("id") int id) {
		return ProductService.getProduct(id);
	}

	/**
	 * Method to create a new Product,supporting HTTP POST method produces Media
	 * type of JSON
	 * 
	 * @FormParam used to retrieve the values entered in html form
	 * @param txtId
	 * @param txtName
	 * @param txtPrice
	 * @return Product
	 */
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("txtPrice") long txtPrice) {
		Product Product = new Product();
		Product.setProductId(txtId);
		Product.setProductName(txtName);
		Product.setPrice(txtPrice);
		return ProductService.addProduct(Product);
	}

	/**
	 * Method to delete a Product,supporting HTTP POST method, here we are using
	 * POST to support delete produces Media type of JSON
	 * 
	 * @param id
	 * @return Product
	 */
	@POST
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Product deleteProduct(@FormParam("txtId") int id) {
		Product Product = ProductService.deleteProduct(id);
		// if valid Product Id is existing then Product gets deleted; otherwise
		// returning a JSON object with default (null) values
		if (Product != null) {
			return Product;
		} else {
			return new Product();
		}

	}

}
