package com.cg.client;


import java.util.List;
import java.util.Scanner;

import com.cg.bean.Author;
import com.cg.service.AuthorServiceImpl;
import com.cg.service.IAuthorService;

public class client {
	public static void main(String[] args){
		
	String mobileNumber;
		int id;
	IAuthorService authorService=new AuthorServiceImpl();
	boolean inProcess=true;
	int choice;
	Scanner scInput=new Scanner(System.in);
	Author author = new Author();
	while(inProcess){
		System.out.println("1.Add Author");
		System.out.println("2.Delete Author");
		System.out.println("3.Find Author");
		System.out.println("4.View All Authors");
		System.out.println("5.update Phone number");
		System.out.println("6.Exit");
		System.out.println("Enter your choice");
		choice=scInput.nextInt();
		scInput.nextLine();
		switch(choice){
		case 1:
			
			System.out.println("Enter Author details");
			System.out.println("Enter first name");
			author.setFirstName(scInput.nextLine());
			System.out.println("Enter Middle name");
			author.setMiddleName(scInput.nextLine());
			System.out.println("Enter Last name");
			author.setLastName(scInput.nextLine());
			System.out.println("Enter Mobile number");
			author.setPhoneNo(scInput.nextLine());
			
			try {
				id=authorService.addAuthor(author);
					System.out.println("author id is "+id);
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case 2:
			System.out.println("Enter auhtor Id");
			
			id=scInput.nextInt();
			scInput.nextLine();
			
			try {
				author=authorService.deleteAuthor(id);
				System.out.println(author);
				System.out.println("Deleted successfully");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
					
			break;
		case 3:
			System.out.println("Enter Author Id");
			id=scInput.nextInt();
			scInput.nextLine();
			
			try {
				author=authorService.findAuthor(id);
				System.out.println(author);
			}catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case 4:
			try {
				List<Author> list=authorService.viewAllAuthor();
				for (Author aut : list) {
					System.out.println(aut);
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
				
			}
			break;
		case 5:
			System.out.println("Enter id for which mobile number to be updated");
			id=scInput.nextInt();
			scInput.nextLine();
			System.out.println("Enter Phone Number");
			mobileNumber=scInput.nextLine();
			try {
				authorService.updateAuhtor(id, mobileNumber);
				System.out.println("Updated successfully");
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
			break;
		case 6:
			inProcess=false;
			break;
			
		}
	}		scInput.close();

	}
}
