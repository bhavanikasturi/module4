package com.cg.service;

import java.util.List;

import com.cg.bean.Author;
import com.cg.dao.AuthorDAOIMPL;
import com.cg.dao.IAuthorDAO;

public class AuthorServiceImpl implements IAuthorService {

	IAuthorDAO authorDao=new AuthorDAOIMPL();
	@Override
	public int addAuthor(Author author) throws Exception {
	
		return authorDao.addAuthor(author);
	}

	@Override
	public Author deleteAuthor(int id) throws Exception {
		
		return authorDao.deleteAuthor(id);
	}

	@Override
	public Author findAuthor(int id) throws Exception {
		
		return authorDao.findAuthor(id);
	}

	@Override
	public List<Author> viewAllAuthor() throws Exception {
		
		return authorDao.viewAllAuthor();
	}

	@Override
	public void updateAuhtor(int id, String phoneNumber) throws Exception {
		authorDao.update(id, phoneNumber);
		
	}

}
