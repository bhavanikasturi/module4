package com.cg.service;

import java.util.List;

import com.cg.bean.Author;

public interface IAuthorService {
	public int addAuthor(Author author)throws Exception;
	public Author deleteAuthor(int id)throws Exception;
	public Author findAuthor(int id)throws Exception;
	public List<Author> viewAllAuthor()throws Exception;
	public void updateAuhtor(int id,String phoneNumber)throws Exception;
}
