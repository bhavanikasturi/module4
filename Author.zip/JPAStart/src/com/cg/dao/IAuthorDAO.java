package com.cg.dao;

import java.util.List;

import com.cg.bean.Author;

public interface IAuthorDAO {

	public int addAuthor(Author author)throws Exception;
	public Author deleteAuthor(int id)throws Exception;
	public Author findAuthor(int id)throws Exception;
	public List<Author> viewAllAuthor()throws Exception;
	public void update(int id,String phoneNumber)throws Exception;
}
