package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.bean.Author;

public class AuthorDAOIMPL implements IAuthorDAO {

	private EntityManager entityManager;
	
	/**
	 * @param entityManager
	 */
	public AuthorDAOIMPL() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public int addAuthor(Author author) throws Exception {
		
		entityManager.getTransaction().begin();
		entityManager.persist(author);
		entityManager.getTransaction().commit();
		return author.getAuthorId();
	}

	@Override
	public Author deleteAuthor(int id) throws Exception {
		entityManager.getTransaction().begin();
		Author author=entityManager.find(Author.class, id);
		if(author==null){
			entityManager.getTransaction().commit();
			throw new Exception("No Author with given Id");
			
		}
		entityManager.remove(author);
		entityManager.getTransaction().commit();
		
		return author;
	}

	@Override
	public Author findAuthor(int id) throws Exception {
	
		entityManager.getTransaction().begin();
		Author author=entityManager.find(Author.class, id);
		if(author==null){
			entityManager.getTransaction().commit();
			throw new Exception("No Author with given Id");
			
		}
		entityManager.getTransaction().commit();
		return author;
	}

	@Override
	public List<Author> viewAllAuthor() throws Exception {
		entityManager.getTransaction().begin();
		TypedQuery<Author> qry=entityManager.createQuery("FROM Author", Author.class);
		List<Author> list=qry.getResultList();
		if(list==null)
		{
			entityManager.getTransaction().commit();
			throw new Exception("No Authors");
		}
		entityManager.getTransaction().commit();
		return list;
	}

	@Override
	public void update(int id,String phoneNumber) throws Exception {
		entityManager.getTransaction().begin();
		Author author=entityManager.find(Author.class, id);
		if(author==null){
			entityManager.getTransaction().commit();
			throw new Exception("No Author with given Id");
			
		}
		author.setPhoneNo(phoneNumber);
		entityManager.merge(author);
		entityManager.getTransaction().commit();
		
	}

	

}
