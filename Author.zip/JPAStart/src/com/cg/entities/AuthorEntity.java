package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

public class AuthorEntity {
	
	@Entity
	@Table(name="author")
	public class Author implements Serializable {
		
		private static final long serialVersionUID = 1L;
		@Id
		private int AuthorId;
		private String fname;
		private String mname;
		private String lname;
		private String phoneno;
		public int getAuthorId() {
			return AuthorId;
		}
		public void setAuthorId(int authorId) {
			AuthorId = authorId;
		}
		public String getFname() {
			return fname;
		}
		public void setFname(String fname) {
			this.fname = fname;
		}
		public String getMname() {
			return mname;
		}
		public void setMname(String mname) {
			this.mname = mname;
		}
		public String getLname() {
			return lname;
		}
		public void setLname(String lname) {
			this.lname = lname;
		}
		public String getPhoneno() {
			return phoneno;
		}
		public void setPhoneno(String phoneno) {
			this.phoneno = phoneno;
		}
		@Override
		public String toString() {
			return "Author [AuthorId=" + AuthorId + ", fname=" + fname
					+ ", mname=" + mname + ", lname=" + lname + ", phoneno="
					+ phoneno + "]";
		}
		
		
		
	}
}
