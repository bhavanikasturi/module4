package com.cg.exception;

public class Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -173040966785805346L;

	/**
	 * 
	 */
	public Exception() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param arg0
	 */
	
	
}
