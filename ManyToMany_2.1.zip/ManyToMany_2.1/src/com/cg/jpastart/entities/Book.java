package com.cg.jpastart.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity

@Table(name="book_table")
public class Book implements Serializable{
	

	public Book() {
		super();
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -1846045404511724077L;
	@Id
	@Column(name="book_id")
	private int ISBN;
	@Column(length=15)
	private String title;
	@Column(length=15)
	private float price;
	
	@ManyToMany(mappedBy="book")
	private Set<Author> author = new HashSet<Author>();

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int ISBN) {
		this.ISBN = ISBN;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Set<Author> getAuthor() {
		return author;
	}

	public void setAuthor(Set<Author> author) {
		this.author = author;
	}
	
	
}
