package com.cg.jpastart.entities;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;


@Entity
@Table(name="author_table")
	
public class Author implements Serializable{
	
	
/**
	 * 
	 */
	private static final long serialVersionUID = 1827514336398764326L;
	
@Id
@Column(name="author_id")
private int ID;
@Column(length=15)
private String name;
	

@ManyToMany(cascade = CascadeType.ALL)

@JoinTable(name = "book_author", joinColumns = { @JoinColumn(name = "author_id") }, inverseJoinColumns = { @JoinColumn(name = "book_id") })
private Set<Book> book = new HashSet<>();

public int getID() {
	return ID;
}

public void setID(int ID) {
	this.ID = ID;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public Set<Book> getBook() {
	return book;
}

public void setBook(Set<Book> book) {
	this.book = book;
}

public void addBook(Book book) {
	this.getBook().add(book);
	
}	



}
