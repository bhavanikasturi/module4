package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");


		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();

		// first define few Books before we place Author

		Book b1 = new Book();
		b1.setISBN(1);
		b1.setTitle("Romeo Juliet");
		b1.setPrice(450);

		Book b2 = new Book();
		b2.setISBN(2);
		b2.setTitle("PROGRAM C");
		b2.setPrice(280);

		Book b3= new Book();
		b3.setISBN(3);
		b3.setTitle("PROGRAM JAVA");
		b3.setPrice(150);

		Book b4 = new Book();
		b4.setISBN(4);
		b4.setTitle("HAMLET");
		b4.setPrice(250);

		// now define first Author and add few Books in it
		Author a1 = new Author();
		a1.setID(1000);
		a1.setName("Shakespeare");
		
		
		Author a2 = new Author();
		a2.setID(1001);
		a2.setName("Bala Guru Swamy");

		a1.addBook(b1);
		a1.addBook(b2);
		a1.addBook(b3);

		a2.addBook(b1);		
		a2.addBook(b3);
		a2.addBook(b4);
		

		// save Authors using entity manager

		em.persist(a1);
		em.persist(a2);

		em.getTransaction().commit();
		em.close();
		emf.close();
	}


	}


